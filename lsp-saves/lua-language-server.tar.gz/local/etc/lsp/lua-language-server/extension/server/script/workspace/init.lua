local workspace = require 'workspace.workspace'

return workspace
